#include <fcntl.h>
#include <assert.h>
int main(int argc,char **argv){ 
	return lsri(argv[1]); 
}
