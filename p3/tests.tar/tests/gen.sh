cat seed > sample0
cat sample0 sample0 sample0 > sample1
cat sample1 sample1 sample1 > sample2
cat sample2 sample2 sample2 > sample3
cat sample3 sample3 sample3 > sample4
cat sample4 sample4 sample4 > sample5
cat sample5 sample5 sample5 > sample6
cat sample6 sample6 sample6 > sample7
cat sample7 sample7 sample7 > sample8
cat sample8 sample8 sample8 > sample9
